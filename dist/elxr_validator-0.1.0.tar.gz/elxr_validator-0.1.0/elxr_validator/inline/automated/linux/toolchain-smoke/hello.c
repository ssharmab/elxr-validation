#include <stdio.h>

void main(int argc)
{
    printf("Hello world");
}
