__import__("pkg_resources").declare_namespace(__name__)
# DO NOT ADD ANYTHING TO THIS FILE!
# IT MUST STAY AS IS (empty apart from the two lines above)
