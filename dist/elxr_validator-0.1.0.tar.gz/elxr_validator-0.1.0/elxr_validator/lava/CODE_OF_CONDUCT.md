See https://docs.lavasoftware.org/lava/code-of-conduct.html
