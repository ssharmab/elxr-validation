See https://docs.lavasoftware.org/lava/contribution.html
