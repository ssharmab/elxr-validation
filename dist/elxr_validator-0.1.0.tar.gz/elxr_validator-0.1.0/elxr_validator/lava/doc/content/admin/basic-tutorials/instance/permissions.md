# User permissions

# authorizations

# private devices/device-types
