# Admin guide

Welcome to the admin guide that will help you setup and admin your LAVA
instances.

# Layout

This guide is split between:

* basic tutorials
* advanced tutorial
