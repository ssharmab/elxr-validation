Use the notifications!
