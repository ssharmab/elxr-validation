# How to find issues

* performances
* crashes
* logs
* job not terminating
* queue not empty
* state machnie
