# Generating job definitions

https://github.com/Linaro/lava-test-plans
