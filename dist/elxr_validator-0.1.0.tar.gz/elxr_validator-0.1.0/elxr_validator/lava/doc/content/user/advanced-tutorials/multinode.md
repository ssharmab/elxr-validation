# Multinode job definition

## How to avoid it

In most cases this is not needed.

Better to avoid it if possible

