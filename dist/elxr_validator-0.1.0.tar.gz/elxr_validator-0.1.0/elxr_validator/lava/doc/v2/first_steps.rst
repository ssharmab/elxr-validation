.. _first_steps_using_lava:

First steps as a user
#####################

.. include:: logging-in.rsti
.. include:: authentication-tokens.rsti

.. #
   first-job
   explain_first_job
   lavacli

   .. include:: first-job.rsti
